# main file of application
from flask import Flask
from extensions import db
from routes.index import main
import models

# basics parameters
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../test.db'
db.init_app(app)

# register routes
app.register_blueprint(main)

# IMG_FOLDER = os.path.join('static', 'img')
# app.config['UPLOAD_FOLDER'] = IMG_FOLDER


# creating table if doesn't exist
with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=True)