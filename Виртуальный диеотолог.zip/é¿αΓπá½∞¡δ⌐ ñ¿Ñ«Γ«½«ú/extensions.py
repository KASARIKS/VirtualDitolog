# for working with db

from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()