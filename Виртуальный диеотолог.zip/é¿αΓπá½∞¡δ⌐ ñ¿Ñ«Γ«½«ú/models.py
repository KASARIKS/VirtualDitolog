# all main models
from extensions import db

class Dishes(db.Model):
    id = db.Column(db.Integer, nullable=False, primary_key=True)
    name = db.Column(db.String(32), nullable=False)
    typee = db.Column(db.String(32), nullable=False)
    cal = db.Column(db.Integer, nullable=False)