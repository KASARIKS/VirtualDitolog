from flask import Blueprint, render_template, request
import models
from extensions import db
import random

main = Blueprint('main', __name__)

@main.route('/', methods=['POST', 'GET'])
def main_page():
    return render_template('index.html')

@main.route('/training', methods=['POST', 'GET'])
def training_page():
    return render_template('choose_training_plan.html')

@main.route('/the_best_in_the_world', methods=['POST', 'GET'])
def the_best_training_page():
    return render_template('the_best_training.html')

@main.route('/for_fat_loss', methods=['POST', 'GET'])
def for_fat_loss_page():
    return render_template('for_fat_loss.html')

@main.route('/for_gym', methods=['POST', 'GET'])
def for_gym_page():
    return render_template('for_gym.html')

@main.route('/for_home', methods=['POST', 'GET'])
def for_home_page():
    return render_template('for_home.html')

@main.route('/nutrition', methods=['POST', 'GET'])
def nutrition_page():
    return render_template('nutrition.html')

@main.route('/show_menu', methods=['POST', 'GET'])
def show_menu():
    # validation
    error_str = []
    
    if request.form['height'] == "":
        error_str.append("Empty height!")
    if request.form['weight'] == "":
        error_str.append("Empty weight!")
    if request.form['age'] == "":
        error_str.append("Empty age!")
    
    if request.form['count_of_lunches'].isalpha():
        error_str.append("Wrong count of lunches!")
        
    if len(error_str) != 0:
        return render_template('error.html', error_str=error_str)
    
    sex = str(request.form['sex'])
    height = int(request.form['height'])
    weight = int(request.form['weight'])
    age = int(request.form['age'])
    cal = 10 * weight + 6.25 * height - 5 * age + (5 if sex[0] in "МмMm" else -161)
    all_carbs = db.session.query(models.Dishes).filter(models.Dishes.typee == "Гарнир")
    all_proteins = None
    fiber_multiplier = 10
    if request.form['special_proteins'] == "Normal":
        all_proteins = db.session.query(models.Dishes).filter(models.Dishes.typee == "Белок")
    elif request.form['special_proteins'] == "Vegat":
        all_proteins = db.session.query(models.Dishes).filter(models.Dishes.typee == "Вегат-Белок")
    elif request.form['special_proteins'] == "Vegan":
        all_proteins = db.session.query(models.Dishes).filter(models.Dishes.typee == "Веган-Белок")
        fiber_multiplier = 5
    all_fiber = db.session.query(models.Dishes).filter(models.Dishes.typee == "Салат")
    
    
    
    # prof or def
    if request.form['type_of_cal'] == "Prof":
        cal += 200
    elif request.form['type_of_cal'] == "Def":
        cal -= 200
    
    # creating menu
    count_of_lunches = int(request.form['count_of_lunches'])
    if count_of_lunches > 5:
        count_of_lunches = 5
    if count_of_lunches < 1:
        count_of_lunches = 1
        
    # choose food
    carbs = []
    proteins = []
    fibers = []
        
    for i in range(count_of_lunches):
        carbs.append(all_carbs[random.randint(0, all_carbs.count() - 1)])
        proteins.append(all_proteins[random.randint(0, all_proteins.count() - 1)])
        fibers.append(all_fiber[random.randint(0, all_fiber.count() - 1)])
    
    
    return render_template('result.html', cal=cal, carbs=carbs, 
                           proteins=proteins, 
                           fibers=fibers,
                           rand_prekok=random.randint(5, 15),
                           count_of_lunches=count_of_lunches,
                           fiber_multiplier=fiber_multiplier)
    
    # db.session.add(models.Dishes(name="рис", typee="Гарнир", cal=130))
    # db.session.add(models.Dishes(name="макароны", typee="Гарнир", cal=371))
    # db.session.add(models.Dishes(name="картофель", typee="Гарнир", cal=77))
    # db.session.add(models.Dishes(name="гречка", typee="Гарнир", cal=343))
    # db.session.add(models.Dishes(name="фасоль", typee="Гарнир", cal=298))
    # db.session.add(models.Dishes(name="перловка", typee="Гарнир", cal=352))
    # db.session.add(models.Dishes(name="хлеб", typee="Гарнир", cal=265))
    
    # db.session.add(models.Dishes(name="говядина", typee="Белок", cal=250))
    # db.session.add(models.Dishes(name="свинина", typee="Белок", cal=242))
    # db.session.add(models.Dishes(name="курица", typee="Белок", cal=239))
    # db.session.add(models.Dishes(name="рыба", typee="Белок", cal=200))
    # db.session.add(models.Dishes(name="баранина", typee="Белок", cal=294))
    # db.session.add(models.Dishes(name="яйца", typee="Белок", cal=155))
    # db.session.add(models.Dishes(name="творог", typee="Белок", cal=232))
    
    # db.session.add(models.Dishes(name="яйца", typee="Вегат-Белок", cal=155))
    # db.session.add(models.Dishes(name="творог", typee="Вегат-Белок", cal=232))
    # db.session.add(models.Dishes(name="сейтан", typee="Вегат-Белок", cal=370))
    
    # db.session.add(models.Dishes(name="соя", typee="Веган-Белок", cal=446))
    # db.session.add(models.Dishes(name="арахис", typee="Веган-Белок", cal=567))
    # db.session.add(models.Dishes(name="сейтан", typee="Веган-Белок", cal=370))
    # db.session.add(models.Dishes(name="грецкий орех", typee="Веган-Белок", cal=607))
    # db.session.add(models.Dishes(name="тыквенные семечки", typee="Веган-Белок", cal=446))

    # db.session.add(models.Dishes(name="огурцы", typee="Салат", cal=15))
    # db.session.add(models.Dishes(name="помидоры", typee="Салат", cal=20))
    # db.session.add(models.Dishes(name="грибы", typee="Салат", cal=22))
    # db.session.add(models.Dishes(name="капуста", typee="Салат", cal=25))
    # db.session.add(models.Dishes(name="брокколи", typee="Салат", cal=34))
    # db.session.add(models.Dishes(name="цветная капуста", typee="Салат", cal=25))
    # db.session.add(models.Dishes(name="болгарский перец", typee="Салат", cal=20))
    # db.session.add(models.Dishes(name="бананы", typee="Салат", cal=96))
    # db.session.add(models.Dishes(name="яблоки", typee="Салат", cal=47))
    # db.session.add(models.Dishes(name="груши", typee="Салат", cal=57))
    # db.session.add(models.Dishes(name="виноград", typee="Салат", cal=72))
    
    # db.session.commit()